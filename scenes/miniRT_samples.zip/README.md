# miniRT Parsing Test Suite

This folder contains a broad set of `.rt` scenes to stress-test a parser.

Legend: VALID scenes should parse; INVALID scenes should trigger an error with an explicit message.

Files:
- 01_valid_minimal.rt — VALID
- 02_valid_whitespace_and_comments.rt — VALID
- 03_valid_extreme_bounds.rt — VALID
- 04_valid_negative_coords_normals.rt — VALID
- 05_bonus_multilights.rt — MIXED
- 06_invalid_duplicate_capitals.rt — VALID
- 07_invalid_token_count_light.rt — VALID
- 08_invalid_color_range.rt — VALID
- 09_invalid_ambient_range.rt — VALID
- 10_invalid_fov_range.rt — VALID
- 11_invalid_vector_format.rt — VALID
- 12_invalid_non_normalized_normal.rt — VALID
- 13_invalid_unknown_identifier.rt — VALID
- 14_invalid_missing_values.rt — VALID
- 15_invalid_extra_values.rt — VALID
- 16_valid_complex_scene.rt — VALID
- 17_tricky_spacing_but_valid_if_tolerant.rt — VALID
- 18_valid_tabs_and_blanklines.rt — VALID
- 19_invalid_rgb_non_integer.rt — VALID
- 20_invalid_float_literals.rt — VALID
- 21_invalid_multiple_lights_mandatory_context.rt — VALID
- 22_valid_large_scene_many_objects.rt — VALID
- 23_invalid_zero_length_normal.rt — VALID
- 24_invalid_negative_dimensions.rt — VALID
- 25_valid_strict_spacing_no_commas_spaces.rt — VALID